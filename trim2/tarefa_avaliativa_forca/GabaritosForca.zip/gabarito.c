#include<stdio.h>
int main(){
	char jogo[3][3];
	int x, y, acabou=0, jogador=1, errado=0, isX=0, isO=0, velha=0;
	
		for(x=0;x<3;x++){// preenche o vetor com '-' para ficar visivel todos espa�os disponiveis
			for(y=0;y<3;y++){
				jogo[x][y]='-';
			}
		}
		
		for(x=0;x<3;x++){//mostra o jogo da velha
			printf("\n");
			for(y=0;y<3;y++){
				printf(" %c ", jogo[x][y]);
			}
		}
		
		
do{// esse "do" faz com que o jogo s� acabade se a variavel "acabou" ficar com valor 1
		if(jogador==1){
			printf("\n\nJOGADOR X");
		}else{
			printf("\n\nJOGADOR O");
		}
		errado=0;
		
		
		
		 /*esse "do" permite que seja possivel controlar caso o jogador digite uma casa que ja esta preenchida com x ou O, ou se a linha e coluna passam dos limites da matriz, 
		ele vai digitar a casa at� que seja uma v�lida, ou seja quando a variavel "errado" valer 1*/
	do{
		printf("\nDigite a linha que deseja marcar:(0 ate 2) ");
		scanf("%d",&x);
		printf("\nDigite a coluna dessa linha que deseja marcar:(0 ate 2)");
		scanf("%d",&y);
		if((x>2 || x<0)||(y>2 || y<0)){
			errado=0;
			printf("\n\nCasa invalida, lembre que eh entre 0 e 2!\n\n");
		}else if(jogo[x][y]=='-'){
			errado=1;
		}else{
			printf("\n\nCasa ja ocupada!!!\n");
			errado=0;
		}
		
	}while(errado==0);
	
	
	
		if(jogador==1){//se for a vez do jogador 1 a casa sera preenchida com x
			jogo[x][y]='X';
			jogador=0;
		}
		else{
			jogo[x][y]='O';
			jogador=1;
		}
		
		
		for(x=0;x<3;x++){//mostra o jogo da velha
			printf("\n");
			for(y=0;y<3;y++){
				printf(" %c ", jogo[x][y]);
			}
		}
		
		for(x=0;x<3;x++){/* esse "for" serve para verificar se existe 3 X ou 3 O na linha 0 depois na linha 1 e depois na linha 2, cada x ou O que tiver a variavel isX ou isO ir� somar mais 1, 
		caso chegue a 3, isso significa que existe uma sequencia, ent�o a variavel "acabou" fica com valor 1 e acaba o jogo*/
			isX=0;
			isO=0;
			for(y=0;y<3;y++){
				if(jogo[x][y]=='X'){
					isX++;
				}
				if(jogo[x][y]=='O'){
					isO++;
				}
			}
			if(isX==3 || isO == 3){
				acabou=1;
			}
		}
		
			for(y=0;y<3;y++){// mesma coisa que o de cima, por�m agora iremos checar as colunas e nao as linhas para ver se existe uma sequencia
			isX=0;
			isO=0;
			for(x=0;x<3;x++){
				if(jogo[x][y]=='X'){
					isX++;
				}
				if(jogo[x][y]=='O'){
					isO++;
				}
			}
			if(isX==3 || isO == 3){
				acabou=1;
			}
		}
		
		
		//diagonal principal para ver se existe uma sequencia de 3 x ou 3 O
			isX=0;
			isO=0;
for(x=0;x<3;x++){
	if(jogo[x][x]=='X'){
		isX++;
	}
	if(jogo[x][x]=='O'){
		isO++;
	}
	if(isX==3 || isO == 3){
				acabou=1;
			}
	
}

// diagonal secundaria
x=0;
isX=0;
isO=0;

for(y=2;y>=0;y--){
	if(jogo[x][y]=='X'){
		isX++;
	}
	if(jogo[x][y]=='O'){
		isO++;
	}
	if(isX==3 || isO == 3){
				acabou=1;
			}
	x++;
}


// verifica se deu velha

	for(x=0;x<3;x++){
			
			for(y=0;y<3;y++){
				
				if(jogo[x][y]=='X' || jogo[x][y]=='O'){
					velha++;
				}
			}
		}
if(velha==9 && acabou==0){
	acabou=1;
	printf("\n\nDEU VELHA!!!");
}
else{
	velha=0;
}


}while(acabou==0);//se a variavel �acabou� virou 1 o jogo acaba
	
	
	
	if(jogador==0 && velha!=9){
		printf("\n\n\n JOGADOR X GANHOU!!!");
	}
	if(jogador==1 && velha!=9){
		printf("\n\n\n JOGADOR O GANHOU!!!");
	}
}



