//Jogo Da Forca//
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <unistd.h>
#include <windows.h>
using namespace std;
int main ()
{
	setlocale(LC_ALL,"");
	
	char palavra[2000] = {},palavra1[21] = {}, dica[1000];
	
	char letra[1], letrasescri[20], p1[20], p2[20];
	int vida=5, tam, lec=0, certo=0, errado=0, certof=0, escolha=0, volta=0;
	
	    
	    
	    
	  
	  
	  while(volta==0)
  {   volta=0;
        printf("\n\t |-------------| |-----|");	
	    printf("\n\t |Jogo da Forca| |     |");
        printf("\n\t |-------------| |   -----");
        printf("\n\t                 |  |_� �_|");
        printf("\n\t                 |     |");
        printf("\n\t                 |  /--|--/");
        printf("\n\t                 |     |");
        printf("\n\t                 |    / / ");
        printf("\n\t               -----");
        system("color 01");Sleep(200);
	    
	    system("color 02");Sleep(200);
	    
	    system("color 03");Sleep(200);
	    
	    system("color 04");Sleep(200);
	    
	    system("color 05"); Sleep(200);
	    
	    system("color 01");Sleep(200);
	    
	    system("color 02");Sleep(200);
	    
	    printf("\n\n\n\t\t1-Jogar\n\n\t\t2-Regras\n\n\t\t3-Cr�ditos\n\n\t\t4-Sair");
	    
		printf("\n\n\t\tDigite aqui:");
		scanf("%i", &escolha);
	    
	    if(escolha == 1)
	    {
		system("cls");
        printf("\n\nPlayer X, digite seu nome:");
        scanf("%s", &p1);
        
        printf("\n\nPlayer O, digite seu nome:");
        scanf("%s", &p2);
        
        system("cls");
        
        printf("Espere o(a) %s sair de perto", p2);
        
        printf(".");Sleep(300);
        
        printf(".");Sleep(300);
        
        printf(".");Sleep(300);
        
        printf(".");Sleep(300);
        
        printf(".");Sleep(300);
        
        printf(".");Sleep(300);
        
        printf(".");Sleep(300);
        
        printf(".");Sleep(300);
        
        system("cls");
        
        printf("\n\n %s digite a palavra aqui:", p1);
		scanf("%s", &palavra);
		
		system("cls");
		
		printf("\n\n %s, digite aqui uma dica:", p1);
		scanf("%s", &dica);
		
		 system("cls");
		
	    
	    tam = strlen(palavra);
	    
	    
		printf("  \n   \n1.O n�mero de letras �: %i\n\n2.A dica dada pelo %s um �: %s\n\n", tam,p1, dica);
	    
	   
	   


  
  	
		
	for(int y=0; y<tam ; y++) {
		     
			 printf("  \n\n  Vidas do %s = %i\n\n", p2, vida);
			 printf("\n");
		
	         printf("\n\nDigite aqui uma letra:");
		     scanf("%s", &letra[0]);
		     certo = 0;
			 errado=0;
			 
			 for(int i = 0; i<=tam; i++){
			
			if(letra[0] == palavra[i])
		{
			
				certo++; 
       }
          
          if(letra[0] != palavra[i])
          {
          	errado++;
		  }
	
       
}
		
   	        if(certo>=1)
			{
				printf("\nParab�ns, voc� acertou %i letras", certo);
				certof = certof + certo;
			}
			if(errado >= 1 and certo == 0)
			{
				vida --;
				printf("\nQue triste, voc� errou  ", errado);
			}
			
			if(vida == 0)
			{  system("cls");
				printf("\n\tVoc� perdeu o jogo :-()\n \n\nA palavra � '%s''", palavra);
	          printf("\n\t           |-----|");	
	    printf(" \n\t                |     |");
        printf("\n\t                 |   -----");
        printf("\n\t                 |  |_x x_|");
        printf("\n\t                 |     |");
        printf("\n\t                 |  /--|--/");
        printf("\n\t                ---    |");
        printf("\n\t                      / / ");
        system("color C");Sleep(100000);
              
              volta=0;
				system("cls");
			}
			if(certof == tam)
			{   system("cls");
		printf("\n\t |             | ");	
	    printf("\n\t | !!Parab�ns!!|      ");
        printf("\n\t |             |    -----   ");
        printf("\n\t                   |_� .�_|");
        printf("\n\t                      |");
        printf("\n\t                   /--|--/");
        printf("\n\t                      |");
        printf("\n\t                     / / ");
        printf("\n\t                   -----");
					system("color 01");Sleep(200);
	    
	            system("color 02");Sleep(500);
	    
	            system("color 03");Sleep(500);
	    
	             system("color 04");Sleep(500);
	    
	            system("color 05"); Sleep(500);
	            
	            
				system("cls");
				
				break;
				
				volta =0;
			}}
}
		if(escolha == 2)
			{
			    system("cls");
				
				printf("\t\tRegras\n\n\n 1-N�o olhe seu advers�rio digitando a palavra\n\n 2-N�o use palavras dificeis\n\n 3-N�o d� dicas falsas!");
			
			   	printf("\n\nDigite 0 para continuar:");
				scanf("%i", &volta);
				system("cls");
			}
	if(escolha == 3)
	{
		system("cls");
		
		printf("\n\t\t\tFeito por Murilo Rodrigues!"); 
			printf("\n\n\t\t\tDigite 0 para continuar:");
				scanf("%i", &volta);
		system("cls");
			}	
			
			if(escolha == 4)
			{
				volta=1;
				}	
				
}

}





